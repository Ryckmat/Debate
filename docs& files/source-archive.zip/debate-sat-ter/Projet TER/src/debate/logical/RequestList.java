/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package debate.logical;

import java.util.ArrayList;

/**
 *
 * @author Propriétaire
 */
public class RequestList {
    ArrayList<Request> requests;

    public RequestList(){
        requests=new ArrayList<Request>();
    }

    public void addRequest(Request r){
        requests.add(r);

    }

    public void removeRequest(Request r){
        requests.remove(r);
    }

    public Request getRequest(int i){
        return requests.get(i);
    }

}
