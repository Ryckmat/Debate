/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package debate.logical;

import satoulouse.Formula;

/**
 *
 * @author Propriétaire
 */
public class Argument {
    FormulaList support = new FormulaList() ;
    Formula conclusion ;
    
    public Argument (FormulaList ensFormule, Formula formuleConclue) {
        this.support = ensFormule;
        this.conclusion = formuleConclue ;
    }
}
