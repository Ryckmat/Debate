/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package debate.logical;

import java.util.ArrayList;
import satoulouse.Formula;

/**
 *
 * @author Propriétaire
 */
public class FormulaList {
    ArrayList<Formula> formulas;

    public FormulaList(){
        formulas=new ArrayList<Formula>();
    }

    public void addFormula(Formula r){
        formulas.add(r);

    }

    public void removeFormula(Formula r){
        formulas.remove(r);
    }

    public Formula getFormula(int i){
        return formulas.get(i);
    }

}
