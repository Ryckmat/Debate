/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package satoulouse;

import kawa.lib.system;

/**
 *
 * @author julien
 */
public class TestFormula {
        /*************************/
    /*                       */
    /*     MAIN              */
    /*                       */
    /*************************/
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        Formula formule = new Formula("(a AND b)");
        
    }
}
