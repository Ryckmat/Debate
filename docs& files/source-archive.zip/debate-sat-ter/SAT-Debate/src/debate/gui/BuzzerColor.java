/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package debate.gui;

/**
 *
 * @author David
 */
public enum BuzzerColor {
    GREEN, ORANGE, RED
}
