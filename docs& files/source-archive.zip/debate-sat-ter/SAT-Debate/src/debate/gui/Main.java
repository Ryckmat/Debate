/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package debate.gui;

import java.applet.Applet;
import javax.swing.JApplet;

/**
 *
 * @author Propriétaire
 */
public class Main{
    public static void main (String[] args){
        new DebateFrameNew().setVisible(true);
    }

}
