/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package debate.gui;

import javax.swing.JLabel;

/**
 *
 * @author julien
 */
public class Buzzer extends JLabel {

    public Buzzer() {
        this.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/redbuzz.png")));
        this.setText("");
    }

    public void setGreen () {
        this.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/greenbuzz.png")));
    }
    
    public void setRed () {
        this.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/redbuzz.png")));
    }
    
    public void setOrange () {
        this.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/orangebuzz.png")));
    }
}
