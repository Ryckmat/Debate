/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package debate.game;

/**
 *
 * @author Propriétaire
 */
public enum HandStatus {

    NoOneHasHand,
    PlayerOneHasHand,
    PlayerTwoHasHand
}
