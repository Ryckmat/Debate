/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package debate.tools;

/**
 *
 * @author David
 */
public enum Success {
    Loading,
    Saving,
    Win
    
,   WinPlayer1, WinPlayer2, Deuce}
