/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package debate.move;

/**
 *
 * @author David
 */
public enum Move {
    Assert,
    Accept,
    Argue,
    Agree,
    Dismantle,
    Challenge,
    Quiz,
    QuizLink,
    Close 

}

