/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package debate.tools;

/**
 *
 * @author david
 */
public enum SoundEnum {
    Buzz,
    Fault,
    Acceptation,
    Win,
    Ace,
    Advantage, 
    Deuce
    
}
